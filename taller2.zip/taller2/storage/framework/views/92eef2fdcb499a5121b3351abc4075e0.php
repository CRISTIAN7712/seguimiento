

<?php $__env->startSection('titulo', 'Sistema de seguimiento - Docentes'); ?>
<?php $__env->startSection("content"); ?>
<h1>Editar docente</h1>
    <div class="container p-4">
        <div class="row">
            <div class="col-md-4">
                <div class="card card-body">
                    <form action="<?php echo e(route('docente.update',$docente->idDocente)); ?>" method="put">
                    <?php echo method_field('PUT'); ?>
                        <label for="cedula">Cédula:</label>
                        <input class="form-control" type="text" name="cedula" id="" value="<?php echo e($docente->cedula); ?>">
                        <label for="nombre">Nombre:</label>
                        <input class="form-control" type="text" name="nombre" id="" value="<?php echo e($docente->nombre); ?>">
                        <label for="apellido">Apellido:</label>
                        <input class="form-control" type="text" name="apellido" id="" value="<?php echo e($docente->apellido); ?>">
                        <label for="celular">Celular:</label>
                        <input class="form-control" type="text" name="celular" id="" value="<?php echo e($docente->celular); ?>">
                        <label for="correo">Correo:</label>
                        <input class="form-control" type="text" name="correo" id="" value="<?php echo e($docente->correo); ?>">
                        <label for="correo">Ciudad:</label>
                        <input class="form-control" type="text" name="ciudad" id="" value="<?php echo e($docente->ciudad); ?>">
                        <label for="contrasena">Contraseña:</label>
                        <input class="form-control" type="password" name="contrasena" id="" value="<?php echo e($docente->contrasena); ?>">
                        <button class="form-control btn btn-success btn-block mt-3">Guardar</button>
                    </form>
                </div>
            </div>
        </div>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('../templates.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('../templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taller2\resources\views/docentes/edit.blade.php ENDPATH**/ ?>