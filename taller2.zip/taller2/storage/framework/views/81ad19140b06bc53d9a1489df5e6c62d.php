
<?php $__env->startSection('titulo','Sistema de Seguimiento - IS'); ?>
<?php $__env->startSection('content'); ?>
<h1>Bienvenido al sistema de seguimiento</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taller2\resources\views/index.blade.php ENDPATH**/ ?>