@extends('templates.template')
@section('titulo','Sistema de Seguimiento - IS')
@section('content')
<h1>Bienvenido al sistema de seguimiento</h1>
@endsection